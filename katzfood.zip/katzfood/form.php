<!DOCTYPE html>
<html>
<head>
	<title>login form</title>
	<link rel="stylesheet" type="text/css" href="" style="background: grey">
</head>
<body>
	<label>First name</label>
	<label>Last name</label>
	<label>Contact</label>
	<label>Address</label>
	<label>Email</label>

</body>
</html>