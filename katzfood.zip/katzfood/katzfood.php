<!DOCTYPE html>
<html lang="en">
  <head>
    <title>katzfood</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>katzfood</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        body{
            background-color:tomato;
            margin-left:  0px;
            margin-right: 0px;

        }
        form label{
            color: #000000;
        }
        form input{
            background-color: gray
        }
        img .scr:hover{
            border-color: red;
        }
        button:hover{
            background-color: green;
            border-color: #f347666;
            border-style: double;
        }
        .px-4 img:hover{
            margin: 5px;
        }
        h1:hover{
            border-color: #000000;
        }

       


    </style>
    </head>
  <body>
    <!-- top menu  -->
<div class="container-fluid">
<nav class="navbar navbar-default" style="background-color:#33adff;
">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#"><i class="glyphicon glyphicon-home
"></i>kataza-nakawa kampala uganda </a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        

        <li><a href="#"><i class="glyphicon glyphicon-envelope">
         </i>collinsspence4@gmail.com</a></li>
    </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><i class="glyphicon glyphicon-earphone
"></i>0785640974/0701783797</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</div>
<!-- end of the top menu  -->

<!--  nav bar starts from here -->
<div class="container-fluid">
  <nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">
       <b><i class="glyphicon glyphicon-home
"></i>katzfood</b>
      </a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
            </ul>
        </li>
      </ul>
      
      <ul class="nav navbar-nav navbar-right" >
        <li><a href="#Home">Home</a></li>
        <li><a href="#Aboutus">About Us</a></li>
        <li><a href="#Our services">Our services</a></li>
        <li><a href="#Pricing">Pricing</a></li>
        <li><a href="#Contact">Contact </a></li>


      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</div>
<!-- end of the nav bar -->

<!-- begining of the slider -->

<div class id="Home">
 <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="images/fruits.jpg" alt="..." style="width: 100%; height: 600px;">
      <div class="carousel-caption">
        <h1 style="font-size: 50px;
        padding-bottom: 200px;
        color:red;
        font-family: serif;">we got you covered</h1>
        <button style="background-color: blue; color: #ffffff; font-size: 30px;
        font-family: sans-serif;">check in <a href="www.techpie.Inc"></a></button></h1>
      </div>
    </div>

</div>
<!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>

</div>

<!-- end of the slider -->
<!-- begining of about us -->
<div class id="Aboutus">
    <div class="container" style="font-size: 16px; font-family: sans-serif;letter-spacing: 2px;">
                <div class="row">
                    <div class="col-md-5 order-md-last wrap-about py-5 wrap-about bg-light">
                        <div class="text px-4 ftco-animate">
                <h2 class="mb-4">katzfood welcomes you all, this is the place you should check in</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                            eserunt mollit anim id est laborum.</p>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                            eserunt mollit anim id est laborum.</p>
                            <p>Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. And if she hasn’t been rewritten, then they are still using her.</p>
                            <p><a href="#" class="btn btn-secondary px-4 py-3">Read More</a></p>
                        </div>
                    </div>
                    <!-- offers -->
                    <div class="container-fluid" style="background-color: tomato;font-size: 20px;">
                        <h2>What We Offer</h2>
                    <div class="col-md-7 wrap-about py-5 pr-md-4 ftco-animate">
            
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, word.</p>
                        <div class="row mt-5">
                            <div class="col-lg-6">
                                <div class="services-2 d-flex">
                                    <div class="icon mt-2 mr-3 d-flex justify-content-center align-items-center"><span class="flaticon-security"></span></div>
                                    <div class="text">
                                        <span class="glyphicon glyphicon-plate"></span><b>breakfast</b><br>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,a.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="services-2 d-flex">
                                    <div class="icon mt-2 mr-3 d-flex justify-content-center align-items-center"><span class="flaticon-reading"></span></div>
                                    <div class="text">
                                        
<span class="glyphicon glyphicon-grain

"></span><b>lunch</b><br>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,a.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="services-2 d-flex">
                                    <div class="icon mt-2 mr-3 d-flex justify-content-center align-items-center"><span class="flaticon-diploma"></span></div>
                                    <div class="text">
                                      <span class="glyphicon glyphicon-cutlery

"></span><b>dinner</b><br>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="services-2 d-flex">
                                    <div class="icon mt-2 mr-3 d-flex justify-content-center align-items-center"></div>
                                    <div class="text">
                                           <span class="glyphicon glyphicon-apple "></span>
                           <h3>cocktail juice</h3>
                                        <p>Far far away, behind the word mountains, far from the countries Vokalia.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
</div>
<!-- end of about us -->
<div class="container-fluid">
    <img src="images/dining.jpeg" width="100%;" height="800px;">
</div>
<!-- our food -->
<div class id="Ourfood">
     <h2 "><center><b>featured food</b></center> </h2><p style="letter-spacing: 2px; padding-left: 100px;" >Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
           m.</p>
           </div>
        </div>


    <div class="container-fluid" style="display: flex; background-color: #ffffff ">
    <marquee >
      <img src="images/folded.jpeg" style="height: 200px; width: 200px;">
      <img src="images/Chips.jpeg" style="height: 200px; width: 200px;">
      <img src="images/fruits.jpg" style="height: 200px; width: 200px;">
      <img src="images/grill.jpeg" style="height: 200px; width: 200px;">
      <img src="images/kfc.jpeg" style="height: 200px; width: 200px;">
      <img src="images/kitchen.jpeg" style="height: 200px; width: 200px;">
    </marquee>
  
    </div>
    <!-- end of container -->

       
        
<!-- end of our food -->
<!-- pricing div -->
<div class id ="Pricing" style="width: 100%;">
     <h2><center><b>Our Pricing</b></center> </h2>

<div class="container-fluid" style="display: flex; " >
  
  <div class="row">
  <div class="col-md-4" style="padding-right: 80px">
    <div class="row">
  <div class="col-sm-30 col-md-30">
    <div class="thumbnail" style="background-color:#deb887; width:400px; height: 500px; border-radius:  " >
      <img src="images/rolex.jpeg" alt="..." style="height: 260px;width: 400px;">

      <div class="caption" style="color: #000000;">
        <h1>Rolex</h1>
        <h2><b>price: 2000 ugx min</b></h2></p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
       </p>
        <button style="background-color: blue;">order now</button>  
      </div>
    </div>
  </div>
</div>
  </div>
  
    </div>
     <div class="row">
  <div class="col-md-4" style="padding-right: 80px">
    <div class="row">
  <div class="col-sm-15 col-md-15">
    <div class="thumbnail" style="background-color:#deb887; width: 400px;height: 500px; ">
      <img src="images/Chips.jpeg" alt="..." style="height: 260px;width: 400px;">

      <div class="caption" style="color: #000000;">
        <h1>Chips</h1>
        <h2><b>price: 2000 ugx min</b></h2></p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
       </p>
        <button style="background-color: blue;">order now</button>  
      </div>
    </div>
  </div>
</div>
  </div>
  
    </div>
    <div class="row">
  <div class="col-md-4" style="padding-right: 80px">
    <div class="row">
  <div class="col-sm-15 col-md-15">
    <div class="thumbnail" style="background-color:#deb887; width: 400px;height: 500px; ">
      <img src="images/folded.jpeg" alt="..." style="height: 260px;width: 400px;">

      <div class="caption" style="color: #000000;">
        <h1>sliced chapati + gravy</h1>
        <h2><b>price: 2000 ugx min</b></h2></p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
       </p>
       <button style="background-color: blue;">order now</button> 
      </div>
    </div>
  </div>
</div>
  </div>
  
    </div>

  </div>
  <div class="container-fluid" style="display: flex; " >
  
  <div class="row">
  <div class="col-md-4" style="padding-right: 80px">
    <div class="row">
  <div class="col-sm-30 col-md-30">
    <div class="thumbnail" style="background-color:#deb887; width:400px; height: 500px; border-radius:  " >
      <img src="images/j44.png" alt="..." >

      <div class="caption" style="color: #000000;">
        <h1>campus juice</h1>
        <h2><b>price: 2000 ugx min </b></h2></p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
       </p>
        <button style="background-color: blue;">order now</button>  
      </div>
    </div>
  </div>
</div>
  </div>
  
    </div>
     <div class="row">
  <div class="col-md-4" style="padding-right: 80px">
    <div class="row">
  <div class="col-sm-15 col-md-15">
    <div class="thumbnail" style="background-color:#deb887; width: 400px;height: 500px; ">
      <img src="images/grill.jpeg" style="height: 260px;width: 400px;">

      <div class="caption" style="color: #000000;">
        <h1>kuku full</h1>
        <h2><b>price: 15000 ugx min</b></h2></p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
       </p>
        <button style="background-color: blue;">order now</button>  
      </div>
    </div>
  </div>
</div>
  </div>
  
    </div>
    <div class="row">
  <div class="col-md-4" style="padding-right: 80px">
    <div class="row">
  <div class="col-sm-15 col-md-15">
    <div class="thumbnail" style="background-color:#deb887; width: 400px;height: 500px; ">
      <img src="images/salad2.jpeg" alt="..." style="height: 260px;width: 400px;">

      <div class="caption" style="color: #000000;">
        <h1>Salad maridadi</h1>
        <h2><b>price: 2000 ugx min</b></h2></p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
       </p>
        <button style="background-color: blue;">order now</button>  
      </div>
    </div>
  </div>
</div>
  </div>
  
    </div>


  </div>
<!-- end of pricing -->
<!-- begining of contact -->
<div class id="Contact"><h2><b>Details</b></h2></div>
<form style="width: 50%;">
  <div class="form-group" style="">
    <label for="name">Fname</label>
    <input type="email" class="form-control" >
    <label for="name">Lname</label>
    <input type="email" class="form-control" id="">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="katzfood@gmail.com">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="*********">
  </div>

  <button type="submit" class="btn btn-default" style="background-color:#8c00ff; color: #ffffff">Submit</button>
</form>

<!-- end of contact -->
<!-- begining of footer -->
<footer style=" background-color:#1a0000; font-size: 18px; margin-bottom: 0px; color: #ffffff" >
   <div class="container-fluid" >
<div class="row">
  <div class="col-xs-6 col-sm-4"><h1 style="color:blue;">Reviews</h1>
<p>Lorem ipsum dolor sit amet, consectetur adiccccccc22elit, sed do eiusmod<br>
<img src="images/t.jpg" width="100px;" height="100px;"><br>peter,resident of katz</p>
<p>tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,<br>
<img src="images/t2.jpg" width="100px;" height="100px;"><br>
spencer,student</p>

  </div>
  
  <!-- Optional: clear the XS cols if their content doesn't match in height -->
  <div class="clearfix visible-xs-block"></div>
  <div class="col-xs-6 col-sm-4" ><h1 style="color:blue;">Our blog</h1>
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
<h2 style="color:blue;">pioneers</h2>
<img src="images/cc.png" style="height: 200px;"><br>
<p>collins spence, specetechpi.Inc</p>

  </div>
   <div class="clearfix visible-xs-block"></div>
  <div class="col-xs-6 col-sm-4" ><h1 style="color:blue">A question in case</h1><br><br>
<p> <span class="glyphicon glyphicon-earphone

"></span>call:0701783797</p><br><br>
<p> <span class="glyphicon glyphicon-envelope

"></span>email collinsspence4@gmail.com</p>

  </div>
</div>
   </div>
   <div>
   

</div>
<p>Subscribe with us!</p>
<label>subscribe</label>
<input type="text" name=""><br><br>
<label>your email</label>
<input type="email" name="">
<button style="background-color:pink </button>

<p style="color: #ffffff; text-align: right; font-family: serif;">&Copyright collinsspence </p>


</footer>
<!-- end of footer --

  </body>
  </html>  